#pragma once

#include <Windows.h>
#include <string>
#include <iostream>

#include <filesystem>

#include <functional>
#include <string>
#include <vector>
#include <cctype>

#include <shlobj_core.h>
#include <fstream>
#include <format>

#include <netfw.h>


